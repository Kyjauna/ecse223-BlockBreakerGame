package ca.mcgill.ecse223.block.persistence;

public class Block223Persistence {

}
